package Model;

public class Carta {
    private final Valor valorCarta;
    private final Naipe naipeCarta;

    //Criando as cartas com valor e naipe
    public Carta(Valor valorCarta, Naipe naipeCarta) {
        this.valorCarta = valorCarta;
        this.naipeCarta = naipeCarta;
    }

    public Valor getValorCarta() {
        return valorCarta;
    }

    public Naipe getNaipeCarta() {
        return naipeCarta;
    }

    //Mostra o valor mais o naipe como string
    @Override
    public String toString() {
        return valorCarta + " de " + naipeCarta;
    }
}
