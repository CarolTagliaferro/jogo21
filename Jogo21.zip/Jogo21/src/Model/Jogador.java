package Model;

import java.util.ArrayList;
import java.util.List;

public class Jogador {
    private List<Carta> mao;

    public Jogador(){
        mao = new ArrayList<>();
    }

    public void addCarta(Carta carta){
        mao.add(carta);
    }

    public int getScore(){
        int score = 0;
        for(Carta carta : mao){
            score += carta.getValorCarta().getValor();
        }
        return score;
    }

    public void mostrarMao(){
        System.out.println("Sua mão: ");
        for(Carta carta : mao){
            System.out.println(carta);
        }
        System.out.println("Pontuação atual: " + getScore());
    }

    public boolean estourou(){
        return getScore() > 21;
    }
}
