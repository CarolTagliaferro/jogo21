package Model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.util.Collections.shuffle;

public class Baralho {
    private List<Carta> cartas;

    //Metodo construtor para criar o baralho inteiro
    public Baralho() {
        this.cartas = new ArrayList<Carta>();
        for (Naipe naipeCarta : Naipe.values()) {
            for(Valor valorCarta : Valor.values()) {
                cartas.add(new Carta(valorCarta, naipeCarta));
            }
        }
        embaralhar();
    }

    //Emabaralhar cartas
    public void embaralhar(){
        Collections.shuffle(cartas);
    }

    //Remover ultima carta do monte
    public Carta drawCard(){
        return cartas.remove(cartas.size()-1);
    }
}
