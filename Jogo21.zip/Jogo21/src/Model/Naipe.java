package Model;

public enum Naipe {
    //Definindo naipe das cartas
    OUROS,
    ESPADA,
    COPAS,
    PAUS
}
