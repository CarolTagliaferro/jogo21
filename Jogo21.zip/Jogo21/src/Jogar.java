import Model.Baralho;
import Model.Carta;
import Model.Jogador;

import java.util.Scanner;

public class Jogar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Baralho baralho = new Baralho();
        Jogador jogador  = new Jogador();
        Jogador maquina  = new Jogador();

        System.out.println("Vamos começar o jogo!");
        System.out.print("\n");

        //Vez do jogador
        while (true) {
            jogador.mostrarMao();
            System.out.print("\n");
        System.out.print("Digite '1' para pegar uma carta ou '2' para parar: ");
        int opcao = sc.nextInt();

        if (opcao == 1) {
            Carta carta = baralho.drawCard();
            System.out.println("Você pegou: " + carta);
            jogador.addCarta(carta);

            if (jogador.estourou()){
                System.out.print("\n");
                System.out.println("Você estourou! Vitória da máquina :(");
                break;
            }
        } else if (opcao == 2) {
            break;
        } else {
            System.out.println("Escolha inválida!");
            }
        }

        //Vez da máquina
        if (!jogador.estourou()) {
            while (maquina.getScore() < jogador.getScore()) {
                Carta carta = baralho.drawCard();
                System.out.println("Máquina pegou: " + carta);
                maquina.addCarta(carta);
            }
            System.out.println("Pontuação da máquina: " + maquina.getScore());

            //Resultado final
            if (maquina.estourou() || jogador.getScore() > maquina.getScore()) {
                System.out.print("\n");
                System.out.println("Parabéns! Você é o vencedor :)");
            } else if (jogador.getScore() == maquina.getScore()) {
                System.out.print("\n");
                System.out.println("Foi um empate!");
            } else {
                System.out.print("\n");
                System.out.println("Que pena! Vitória da máquina :(");
            }
        }
        sc.close();
    }
}



